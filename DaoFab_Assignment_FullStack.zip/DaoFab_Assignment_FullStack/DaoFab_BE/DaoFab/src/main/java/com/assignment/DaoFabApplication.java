package com.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class DaoFabApplication {
    public static void main(String[] args) {
        SpringApplication.run(DaoFabApplication.class, args);
    }
}

// Parent class to represent a transaction
class Parent {
    public int id;
    public String sender;
    public String receiver;
    public int totalAmount;
    public List<Child> children = new ArrayList<>();

    public Parent(int id, String sender, String receiver, int totalAmount) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.totalAmount = totalAmount;
    }
}

// Child class to represent installment payment
class Child {
    public int id;
    public String sender;
    public String receiver;
    public int totalAmount;
    public int parentId;
    public int paidAmount;

    public Child(int id, int parentId, String sender, String receiver, int totalAmount, int paidAmount) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.totalAmount = totalAmount;
        this.parentId = parentId;
        this.paidAmount = paidAmount;
    }
}

// Enable cross-origin requests from http://localhost:3000
@CrossOrigin(origins = "http://localhost:3000")
@RestController
class ParentController {
    // Endpoint to fetch parent data
    @GetMapping("/api/parent")
    public List<Parent> getParentData() {
        List<Parent> parents = new ArrayList<>();
        parents.add(new Parent(1, "ABC", "XYZ", 200));
        parents.add(new Parent(2, "EFG", "PQR", 300));
        return parents;
    }
}

// Enable cross-origin requests from http://localhost:3000
@CrossOrigin(origins = "http://localhost:3000")
@RestController
class ChildController {
    private List<Child> childData = new ArrayList<>();

    // Initialize child data
    public ChildController() {
        childData.add(new Child(1, 1, "ABC", "XYZ", 200, 10));
        childData.add(new Child(2, 1, "EFG", "PQR", 300, 50));
        childData.add(new Child(3, 2, "MNO", "WXY", 300, 30));
    }

    // Endpoint to fetch child data
    @GetMapping("/api/child")
    public List<Child> getChildData() {
        return childData;
    }
}
