import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  // State variables to store data
  const [parentData, setParentData] = useState([]);
  const [childData, setChildData] = useState([]);
  const [selectedParentId, setSelectedParentId] = useState(null);

  // Fetch parent data on component mount
  useEffect(() => {
    fetch('http://localhost:8080/api/parent')
      .then(response => response.json())
      .then(data => setParentData(data));
  }, []);

  // Fetch child data for the selected parent
  const fetchChildData = (parentId) => {
    fetch(`http://localhost:8080/api/child?parentId=${parentId}`)
      .then(response => response.json())
      .then(data => setChildData(data));
  };

  // Filter child data based on selected parent
  const filteredChildData = childData.filter(child => child.parentId === selectedParentId);

  return (
    <div className="App">
      <h1>Parent Transactions</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Sender</th>
            <th>Receiver</th>
            <th>Total Amount</th>
            <th>Total Paid Amount</th>
          </tr>
        </thead>
        <tbody>
          {parentData.map(parent => (
            <tr key={parent.id}>
              <td>{parent.id}</td>
              <td>{parent.sender}</td>
              <td>{parent.receiver}</td>
              <td>{parent.totalAmount}</td>
              <td onClick={() => {
                setSelectedParentId(parent.id);
                fetchChildData(parent.id);
              }}>
                Click to view Child data
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {selectedParentId !== null && (
        <div>
          <h2>Child Installments for Parent ID {selectedParentId}</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Sender</th>
                <th>Receiver</th>
                <th>Total Amount</th>
                <th>Paid Amount</th>
              </tr>
            </thead>
            <tbody>
              {filteredChildData.map(child => (
                <tr key={child.id}>
                  <td>{child.id}</td>
                  <td>{child.sender}</td>
                  <td>{child.receiver}</td>
                  <td>{child.totalAmount}</td>
                  <td>{child.paidAmount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default App;
