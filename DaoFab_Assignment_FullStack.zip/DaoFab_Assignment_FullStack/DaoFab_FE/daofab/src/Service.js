
import axios from 'xios';
const API_DATA='http://localhost:8080/api/parent';

class Service{
    getParents(){
        return axios.get(API_DATA);
    }
}

export default new Service();